import React from 'react';
import { useNavigate } from 'react-router-dom';

const Exchange = (props) => {
  const {
    data,
    setData,
    setTotal,
    total,
    setChange,
    totalBill,
    setTotalBill,
    totalGiven,
    setTotalGiven,
    setBill,
    setGiven,
  } = props;

  const nav = useNavigate();
  const changeNote = (totalReturnAmount, data) => {
    let exchangeNote = [];
    for (let index = data.length - 1; index >= 0; index--) {
      const { noOfNote } = data[index];
      const { Note } = data[index];
      console.log(Note, noOfNote);
      if (totalReturnAmount / Note >= noOfNote) {
        const amount =
          Note > 0 ? Math.floor(Note * noOfNote) : (Note * noOfNote).toFixed(2);
        exchangeNote.push({ Note: Note, manyNote: noOfNote });
        noOfNote = 0;
        totalReturnAmount -= amount;
      } else if (totalReturnAmount / Note < noOfNote) {
        const no_of_note =
          Note > 0
            ? Math.floor(totalReturnAmount / Note)
            : (totalReturnAmount / Note).toFixed(2);
        noOfNote -= no_of_note;
        // return { Note: Note, manyNote: no_of_note };
        exchangeNote.push({ Note: Note, manyNote: no_of_note });
        totalReturnAmount = (totalReturnAmount % Note).toFixed(2);
      }
    }
    return exchangeNote;
  };

  const submitHandle = () => {
    if (totalBill === '' || totalBill === 0) {
      alert('Please Enter Total Bill Amount');
    } else if (totalGiven === '' || totalGiven === 0) {
      alert('Please Enter Total Given Amount');
    } else if (totalBill > totalGiven) {
      alert('Total Bill is Not Greater Than Total Given');
    } else if (totalGiven - totalBill > total) {
      alert('Fund Not Available');
    } else {
      // const datas = [...data];
      // console.log(datas);
      let exchangeNote = [];
      const totalReturnAmount = +(totalGiven - totalBill).toFixed(2);

      // console.log(data[index].Note);
      console.log(totalReturnAmount);
      exchangeNote = changeNote(totalReturnAmount, data);
      console.log(exchangeNote);
      // console.log(exchangeNote);
    }
  };
  return (
    <div align="center" style={{ marginTop: '16px' }}>
      <h2>Exchange</h2>
      <table style={{ width: '40%' }}>
        <tbody>
          <tr>
            <td>
              <label>Total Bill</label>
            </td>
            <td>
              <input
                type="number"
                style={{ padding: '10px 20px', fontSize: '15px' }}
                value={totalBill}
                onChange={(e) => setTotalBill(+e.target.value)}
              />
            </td>
            <td>
              <label>Total Given</label>
            </td>
            <td>
              <input
                type="number"
                style={{ padding: '10px 20px', fontSize: '15px' }}
                value={totalGiven}
                onChange={(e) => setTotalGiven(+e.target.value)}
              />
            </td>
            <td>
              <button className="buttons button1" onClick={submitHandle}>
                Submit
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  );
};
export default Exchange;
